<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="style.css">
    </head>
        <body style="width:100%;height:100%;">
            <div id="healthp1">100</div><div id="healthp2">100</div>
            <h1 id="headder">JD's Rpg Battle Helper</h1><br>
                    <button onclick="play()">play</button>
                 <!-- DIE BUTTON <button onclick="alert(randInt(1,NUMBER_OF_SIDES))">NUMBER_OF_SIDES</button> -->
                <!--<h1>Roll Dice: </h1><br><button id="stelth" onclick="rollDie(20)">Stelth</button><button id="chance" onclick="rollDie(15)">Chance</button><button id="C_Chance" onclick="rollDie(15)">Critical Chance</button><br><br><button id="Me_Attack" onclick="rollDie(35)">Melee Attack</button><button id="R_Attack" onclick="rollDie(30)">Ranged Attack</button><button id="M_Attack" onclick="rollDie(25)">Magic Attack</button><br><br><button id="Postion" onclick="rollDie(10)">Postion(witch)</button>--><br><br><br>
                <div id="Dice">0</div>
                <div id="players">
                    <div id="closePlayers" onclick="closePlayers()">X</div>
                    <br><br><br>
                    <div>Player 1<br>
                    <select id="P1">
                        <option value="warrior">warrior</option>
                        <option value="archer">archer</option>
                        <option value="thief">thief</option>
                        <option value="bishop">bishop</option>
                        <option value="wizard">wizard</option>
                        <option value="mage">mage</option>
                        <option value="assassin">assassin</option>
                        <option value="rouge">rouge</option>
                        <option value="gunslinger">gunslinger</option> 
                        <option value="witch">witch</option>
                    </select>
                    </div><br><br><br>
                    <div>Player 2<br>
                    <select id="P2">
                        <option value="warrior">warrior</option>
                        <option value="archer">archer</option>
                        <option value="thief">thief</option>
                        <option value="bishop">bishop</option>
                        <option value="wizard">wizard</option>
                        <option value="mage">mage</option>
                        <option value="assassin">assassin</option>
                        <option value="rouge">rouge</option>
                        <option value="gunslinger">gunslinger</option> 
                        <option value="witch">witch</option>
                    </select><br><br>
                    <button onclick="inputvalue()">Done!</button>
                    </div>
                </div>
                <p>
                    <h1>Classes:</h1><br>
                    <h2>
                    <p class="classPlayer" id="warrior">Warrior - <button class="attackP1">Slash(melee)</button>, <button class="attackP1">Heavy Attack(Heavy Attack, Chance:12)</button>, <button class="attackP1">Blood Rage((Special) Chance:15)</button>, <button class="attackP1">Heal</button><br><br></p>
                    <p class="classPlayer" id="archer">Archer - Arrow(ranged), 2 Arrows(Heavy Attack, Chance:12), Heal<br><br></p>
                    <p class="classPlayer" id="thief">Thief - Stab(melee), Dule Blades(Heavy Attack, Chance:12), Heal<br><br></p>
                    <p class="classPlayer" id="bishop">Bishop - Holy Water(magic), Holy Beam (Heavy Attack, Chance:13), Curse(Special, Chance:16), Heal<br><br></p>
                    <p class="classPlayer" id="wizard">Wizard - Shocking Staff(melee), Shock(magic), Thunder(magic x2 Chance:12), Heal<br><br></p>
                    <p class="classPlayer" id="mage">Mage - Fire Fist(melee), Fireball(magic), Flamethrower(magic x2 Chance:12), Heal<br><br></p>
                    <p class="classPlayer" id="assassin">Assassin - Stab(melee), Back Stab(melee x2 Chance:12), Throwing Knife(ranged), Heal<br><br></p>
                    <p class="classPlayer" id="rouge">Rouge - Stab(melee), Rage(meleex2 Chance:10), Heal<br><br></p>
                    <p class="classPlayer" id="gunslinger">Gunslinger - Shoot(ranged), Rapid Fire(ranged x2 Chance:12), Heal<br><br></p>
                    <p class="classPlayer" id="witch">Witch - Splash of Damage(postion), Scratch(melee), Voodo(magic), Heal<br><br></p><br>
                    </h2>
                    
                    <h1>Attack:</h1><br>
                    <h2>
                    Damage = 10<br><br>
                    Special = 20<br><br>
                    Heavy attack damage = 15<br><br>
                    Melee Attacks - Chance:4, Critical Chance:8<br><br>
                    Ranged Attacks - Chance:4, Critical Chance:7<br><br>
                    Magic Attacks - Chance:4, Critical Chance:8<br><br>
                    Heal - 25, Chance:5, Bonus helth:9<br><br>
                    Postion(witch) - Damage:5 for 2 rounds, Chance:7<br><br>
                    Block - Chance:3<br><br>
                    Doge - Chance:7<br><br>
                    Deflect - Chance:8<br><br>
                    Stun - Chance:8<br><br><br>
                    </h2>
                    <h1>Gameplay:</h1><br>
                    <h2>
                    Both players have 100 hp (use paper if you need to count or something lol(For now)) -<br>
                    To start the game the players with the most stelth goes first by rolling the die -<br>
                    If the player doges sucsessfuly the player can go again aswell as block but blocking still hurts but grater chance to block -<br>
                    Doges and blocks can only be used by the player being attacked when attacker rolls their attack -<br>
                    You cannot block magic attacks, but doge can -<br>
                    If player uses Deflect sucsessfuly next player needs to roll a damage dice which reflects onto themselves -<br>
                    If Stun is used sucsessfuly then the player that used stun goes 2 more times -<br><br>
                    </h2>
                </p>
    V.0.2.5B &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;JDtheman19&#169;
        </body>
        <script defer src="script.js"></script>
</html>
